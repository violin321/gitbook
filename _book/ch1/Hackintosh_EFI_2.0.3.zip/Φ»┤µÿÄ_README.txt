1、替换EFI后执行下面的命令

   sudo sh -c "$(curl -fsSL https://gitee.com/xiaoMGit/Y7000Series_Hackintosh_Fix/raw/master/Script/Optimize.sh)"

2、2018款y7000和y530支持数字键盘，使用方法如下

  1）移除 EFI/CLOVER/kexts/Other/VoodooPS2Controller_Release_v1.9.2.kext
  2）添加 kext/ApplePS2Controller_Release_v4.6.8.kext 到 EFI/CLOVER/kexts/Other

3、屏蔽三星PM981/PM981a
  
  将 hotpatch/SSDT-DNVMe.aml 添加到 EFI/CLOVER/ACPI/patched


1. Execute the following command after replacing EFI.

    sudo sh -c "$(curl -fsSL https://gitee.com/xiaoMGit/Y7000Series_Hackintosh_Fix/raw/master/Script/Optimize.sh)"

2. 2018 models y7000 and y530 support Numeric keypad, how to use

   1) Remove EFI/CLOVER/kexts/Other/VoodooPS2Controller_Release_v1.9.2.kext
   2) Add kext/ApplePS2Controller_Release_v4.6.8.kext to EFI/CLOVER/kexts/Other

3. Shield Samsung PM981/PM981a
  
   Add hotpatch/SSDT-DNVMe.aml to EFI/CLOVER/ACPI/patched


   